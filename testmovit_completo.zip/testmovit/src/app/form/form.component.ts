import { Component, OnInit } from '@angular/core';
import { DepartamentoService } from '../services/departamento.service';
import { CiudadService } from '../services/ciudad.service';
import { CotizacionService } from '../services/cotizacion.service';
import { HttpClient } from '@angular/common/http';
import {Departamento} from '../interfaces/departamento';
import {Ciudad} from '../interfaces/ciudad';
import {Cotizacion} from '../interfaces/cotizacion';
import {FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  departamentos: Departamento[];
  ciudades: Ciudad[];
  public selectedDepartamento:  Departamento = {id:0, nombre:''};
  cotizacion: Cotizacion = {
    nombre: null,
    telefono: null,
    vehiculo: null,
    email: null,
    departamento_id: null,
    ciudad_id: null
  };
  createFormGroup(){
    return new FormGroup({
      nombre: new FormControl('', [Validators.required, Validators.minLength(10)]),
      telefono: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]),
      email: new FormControl('', [Validators.required, Validators.email]),
      vehiculo: new FormControl('', Validators.required),
      departamento_id: new FormControl('', Validators.required),
      ciudad_id: new FormControl('', Validators.required),
      terminos: new FormControl('', Validators.required),
    });
  }
  contactForm: FormGroup;
  constructor(private cotizacionService: CotizacionService, private departamentoService: DepartamentoService, private ciudadService:CiudadService, private httpClient: HttpClient, private spinnerService: Ng4LoadingSpinnerService) {
    this.contactForm = this.createFormGroup();
  }

  ngOnInit() {
    this.departamentoService.get().subscribe((data: Departamento[]) =>{
      this.departamentos = data;
      // console.log(data);
    },
    (error)=>{
      console.log(error);
    });

  }

  onSelect(id:any){
    this.ciudadService.get(id).subscribe((data: Ciudad[]) =>{
      this.ciudades = data;
    },
    (error)=>{
      console.log(error);
    });
  }

  onSaveForm() {
    if(this.contactForm.valid){
      this.spinnerService.show();
      this.cotizacionService.save(this.cotizacion).subscribe((data) => {
        if (data["status"]=="success") {
          alert('Se enviaron correctamente los datos, espera una pronta respuesta.');
        }else{
          alert(data["message"]);
        }
        this.contactForm.reset();
        this.spinnerService.hide();
        console.log(data["status"]);
      }, (error) => {
        console.log(error);
        this.spinnerService.hide();
        alert('ocurrio un error interno');
      });

    }else{
      alert('Por favor diligenciar completo el formulario');
      console.log('no valid');
    }
  }

  get nombre(){ return this.contactForm.get('nombre'); }
  get telefono(){ return this.contactForm.get('telefono'); }
  get email(){ return this.contactForm.get('email'); }
  get vehiculo(){ return this.contactForm.get('vehiculo'); }
  get departamento_id(){ return this.contactForm.get('departamento_id'); }
  get ciudad_id(){ return this.contactForm.get('ciudad_id'); }
  get terminos(){ return this.contactForm.get('terminos'); }

}
