export interface Cotizacion{
  id?: number;
  nombre: string;
  telefono: number;
  vehiculo: string;
  email: string;
  departamento_id: number;
  ciudad_id: number;
  fecha?: string;
  create_at?: string;
  update_at?: string;
}
