export interface Departamento{
  id?: number;
  nombre: string;
}
