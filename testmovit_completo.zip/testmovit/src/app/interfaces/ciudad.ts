export interface Ciudad{
  id?: number;
  nombre: string;
  departamento_id: number;
}
