<!DOCTYPE html>
<html>
<head>
  <title>Cotizacion</title>
</head>

<body>
  <h1>Solicitud Cotizacion</h1>
  <p>Recibiste un mensaje de: <?php echo e($msg["nombre"]); ?></p>
  <p>Correo: <?php echo e($msg["email"]); ?></p>
  <p>Telefono: <?php echo e($msg["telefono"]); ?></p>
  <p>Vehiculo: <?php echo e($msg["vehiculo"]); ?></p>
  <p>Departamento: <?php echo e($msg["departamento"]); ?></p>
  <p>Ciudad: <?php echo e($msg["ciudad"]); ?></p>
</body>
</html>
