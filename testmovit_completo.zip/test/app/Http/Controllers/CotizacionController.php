<?php

namespace App\Http\Controllers;

use App\Cotizacion;
use App\Departamento;
use App\Ciudad;
use Illuminate\Http\Request;
use App\Mail\MensajeCotizacion;
use Illuminate\Support\Facades\Mail;

class CotizacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $departamentos = Cotizacion::get();
      echo json_encode($departamentos);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cotizacionDia = Cotizacion::where("email",$request->input("email"))->where("fecha",date("Y-m-d"))->get();
        if (count($cotizacionDia)>0) {
          $respuesta = array("status"=>"error","message"=>"Ya existe una solicitud de cotizacion para el dia de hoy.");
        }else{
          $cotizacion = new Cotizacion();
          $cotizacion->nombre = $request->input("nombre");
          $cotizacion->telefono = $request->input("telefono");
          $cotizacion->email = $request->input("email");
          $cotizacion->vehiculo = $request->input("vehiculo");
          $cotizacion->departamento_id = $request->input("departamento_id");
          $cotizacion->ciudad_id = $request->input("ciudad_id");
          $cotizacion->fecha = date("Y-m-d");
          $cotizacion->save();
          $respuesta = array("status"=>"success","message"=>"Registro exitoso.");
          $departamento = Departamento::select("nombre")->where("id",$request->input("departamento_id"))->get();
          $cotizacion->departamento = $departamento[0]->nombre;
          $ciudad = Ciudad::select("nombre")->where("id",$request->input("ciudad_id"))->get();
          $cotizacion->ciudad = $ciudad[0]->nombre;
          $destinatarios = ['jaguilar@processoft.com.co', 'jcastro@processoft.com.co', 'mahernandez@processoft.com.co'];
          Mail::to($destinatarios)->send(new MensajeCotizacion($cotizacion));
        }
        echo json_encode($respuesta);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Cotizacion  $cotizacion
     * @return \Illuminate\Http\Response
     */
    public function show(Cotizacion $cotizacion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Cotizacion  $cotizacion
     * @return \Illuminate\Http\Response
     */
    public function edit(Cotizacion $cotizacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Cotizacion  $cotizacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cotizacion $cotizacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Cotizacion  $cotizacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cotizacion $cotizacion)
    {
        //
    }
}
