<!DOCTYPE html>
<html>
<head>
  <title>Cotizacion</title>
</head>

<body>
  <h1>Solicitud Cotizacion</h1>
  <p>Recibiste un mensaje de: {{ $msg["nombre"] }}</p>
  <p>Correo: {{ $msg["email"] }}</p>
  <p>Telefono: {{ $msg["telefono"] }}</p>
  <p>Vehiculo: {{ $msg["vehiculo"] }}</p>
  <p>Departamento: {{ $msg["departamento"] }}</p>
  <p>Ciudad: {{ $msg["ciudad"] }}</p>
</body>
</html>
