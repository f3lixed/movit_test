CREATE DATABASE `testmovit` /*!40100 DEFAULT CHARACTER SET latin1 */;
use `testmovit`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `departamentos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `ciudads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departamento_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ciudads_departamento_id_foreign` (`departamento_id`),
  CONSTRAINT `ciudads_departamento_id_foreign` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `cotizacions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` bigint(20) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehiculo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departamento_id` int(10) unsigned DEFAULT NULL,
  `ciudad_id` int(10) unsigned DEFAULT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cotizacions_departamento_id_foreign` (`departamento_id`),
  KEY `cotizacions_ciudad_id_foreign` (`ciudad_id`),
  CONSTRAINT `cotizacions_ciudad_id_foreign` FOREIGN KEY (`ciudad_id`) REFERENCES `ciudads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cotizacions_departamento_id_foreign` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO `departamentos` (`nombre`) VALUES ('Valle del Cauca');
INSERT INTO `departamentos` (`nombre`) VALUES ('Antioquia');
INSERT INTO `departamentos` (`nombre`) VALUES ('Bogota DC');

INSERT INTO `ciudads` (`nombre`,`departamento_id`) VALUES ('Cali',1);
INSERT INTO `ciudads` (`nombre`,`departamento_id`) VALUES ('Yumbo',1);
INSERT INTO `ciudads` (`nombre`,`departamento_id`) VALUES ('Palmira',1);
INSERT INTO `ciudads` (`nombre`,`departamento_id`) VALUES ('Medellin',2);
INSERT INTO `ciudads` (`nombre`,`departamento_id`) VALUES ('Bogota',3);
